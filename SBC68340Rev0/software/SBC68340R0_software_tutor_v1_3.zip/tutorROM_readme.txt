3/18/25
burning tutor in ROM:
comment out the reset and stack values in 0x0
org the tutor program at $44000, above the 340bug 
insert "bra $44152" at $44000, for an easy to remember jump location

once assembled, save the S record to tutorROM.bin, then combine the program with 340bug (add offset of 4000 to tutorROM.bin).